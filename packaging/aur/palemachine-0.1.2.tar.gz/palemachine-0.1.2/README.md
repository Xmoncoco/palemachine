is the new version of palemachine stay tuned.
now working but the readme is still WIP just use the ./installation_scripts/build where you want to install the folder.
